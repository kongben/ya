// 示例用户插件：关键字 hi，回显输入内容
declare const __registerPlugin: (p: any) => void;
declare const callBridge: (action: string, payload?: any) => Promise<any>;
declare const __lang: () => string;

__registerPlugin({
  onQuery(arg: string, container: HTMLElement) {
    const zh = typeof __lang === "function" && __lang() === "zh";
    if (!arg.trim()) {
      container.innerHTML = `<div class="calc-empty">${
        zh ? "随便输入点什么，我会回显它" : "Type something, I'll echo it"
      }</div>`;
      return;
    }
    container.innerHTML =
      `<div class="calc-result">${arg}</div>` +
      `<div class="calc-hint">${zh ? "Enter 复制到剪贴板" : "Enter to copy"}</div>`;
  },
  onKey(e: KeyboardEvent): boolean {
    const el = document.querySelector(".calc-result");
    if (e.key === "Enter" && el && el.textContent) {
      callBridge("setClipboard", { text: el.textContent });
      callBridge("hide");
      return true;
    }
    return false;
  },
});
